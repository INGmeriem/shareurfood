package com.example.elazaoui.projet;

/**
 * Created by elazaoui on 02/03/16.
 */



public class Food {

    String nomP;
    String descriptionP;
    float prixP;
    int quantiteP;
    String typeP;

    public Food(String nomP, String descriptionP, float prixP, int quantiteP, String typeP) {
        this.nomP = nomP;
        this.descriptionP = descriptionP;
        this.prixP = prixP;
        this.quantiteP = quantiteP;
        this.typeP = typeP;




    }


}

